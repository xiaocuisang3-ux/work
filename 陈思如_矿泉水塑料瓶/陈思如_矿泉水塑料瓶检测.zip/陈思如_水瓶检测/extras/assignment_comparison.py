﻿from pathlib import Path
from ultralytics import YOLO
import json
r=Path(r'C:\Users\HUAWEI\Desktop\YOLO_WaterBottle_Project');out=r/'assignment_evidence';out.mkdir(exist_ok=True);records={}
for v in [2,4]:
 m=YOLO(r/f'05_training_results/water_bottle_v{v}/weights/best.pt');met=m.val(data=str(r/'11_dataset_v4/data.yaml'),split='val',imgsz=640,batch=4,device='cpu',workers=0,conf=.001,iou=.7,project=str(out),name=f'v{v}_same_val',verbose=False);records[str(v)]={k:float(z) for k,z in met.results_dict.items()}
 results=m.predict(source=str(r/'11_dataset_v4/images/val'),conf=.5,iou=.5,imgsz=640,device='cpu',save=True,project=str(out),name=f'v{v}_fixed_predict',verbose=False);records[str(v)]['fixed_predictions']=[{'file':Path(x.path).name,'boxes':len(x.boxes)} for x in results]
json.dump(records,open(out/'comparison.json','w',encoding='utf8'),indent=2);print('COMPARISON_COMPLETE')
