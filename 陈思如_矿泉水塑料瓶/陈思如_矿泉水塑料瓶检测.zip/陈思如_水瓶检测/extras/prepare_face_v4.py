﻿from pathlib import Path
import shutil,json,csv,hashlib
from PIL import Image
r=Path(r'C:\Users\HUAWEI\Desktop\YOLO_WaterBottle_Project');out=r/'11_dataset_v4';assert not out.exists();old=r/'09_dataset_v3'
for split in ['train','val','test']:
 for kind in ['images','labels']:
  (out/kind/split).mkdir(parents=True,exist_ok=True)
  for p in (old/kind/split).iterdir():
   if p.is_file() and p.suffix.lower()!='.cache':shutil.copy2(p,out/kind/split/p.name)
new=r/'10_face_samples';manifest=[]
for folder in ['negative_faces','positive_face_bottle']:
 for p in sorted((new/folder).glob('*.jpg')):
  i=int(p.stem[-3:])
  if folder=='positive_face_bottle' and i==7:continue
  split=('val' if i==7 else 'test' if i==10 else 'train') if folder=='negative_faces' else 'train'
  # New positive examples are added only to train; old held-out splits remain intact.
  lab=new/'labels'/(p.stem+'.txt');assert lab.exists();shutil.copy2(p,out/'images'/split/p.name);shutil.copy2(lab,out/'labels'/split/lab.name);manifest.append([split,p.name,str(p),folder])
with open(out/'added_samples.csv','w',encoding='utf-8-sig',newline='') as f:w=csv.writer(f);w.writerow(['split','image','source','group']);w.writerows(manifest)
(out/'data.yaml').write_text('path: '+out.as_posix()+'\ntrain: images/train\nval: images/val\ntest: images/test\nnames:\n  0: water_bottle\n',encoding='utf8')
counts={};seen={}
for split in ['train','val','test']:
 images=list((out/'images'/split).iterdir());labs=list((out/'labels'/split).glob('*.txt'));assert {p.stem for p in images}=={p.stem for p in labs};neg=boxes=0
 for p in images:
  Image.open(p).verify();h=hashlib.sha256(p.read_bytes()).hexdigest();assert h not in seen,('duplicate',p,seen.get(h));seen[h]=str(p)
 for p in labs:
  lines=p.read_text().strip().splitlines();neg+=not bool(lines)
  for line in lines:
   c,x,y,w,h=map(float,line.split());assert c==0 and w>0 and h>0 and x-w/2>=-1e-5 and y-h/2>=-1e-5 and x+w/2<=1.00001 and y+h/2<=1.00001;boxes+=1
 counts[split]={'images':len(images),'negative':neg,'boxes':boxes}
json.dump(counts,open(out/'checks.json','w',encoding='utf8'),indent=2);(out/'说明.txt').write_text('第四版：保留第三版原划分；新增7张正样本和10张人脸负样本。007号正样本待复核排除。新增正样本仅入训练；新增负样本8张训练、1张验证、1张测试。未做身份识别或标注人脸。内部哈希重复、标签配对和边界检查通过；尚未全量审核跨来源近似场景。验证/测试小且公开图与真实摄像头存在差异。',encoding='utf8');print(counts)
